#include "libSocket/client.h"
#include "libAllegro/AllegroCore.h"

#define LARGURA 1024
#define ALTURA 768

int main(int argc, char const *argv[]){
    
    //INICIALIZACAO DOS MOULOS CENTRAIS
    if (!coreInit())
        return -1;

    //CRIA A JANELA ( WIDTH, HEIGHT, TITLE )
    if (!windowInit(LARGURA, ALTURA, "Target Client"))
        return -1;

    //INICIALIZA O TECLADO E O MOUSE
    if (!inputInit())
        return -1;

    //INICIALIZA AS FONTES
    if(!fontInit())
        return -1;

    //INICIALIZA AS IMAGENS DO MENU INICIAL 
    if(!loadGraphics())
        return -1;
 
    //DEMO == false ( CONDICAO PARA O JOGO FECHAR )
    bool inicio = true;
    bool menu = true;
    bool game = true;
    int count = 0;
    int option;
    
    // CRIA UM CIRCULO QUE VAI SER O NOSSO "CURSOR"
    float x = 50, y = 50;
    
    bool up(int y ){
        if(y > 0)
        y = y - 1;
        
        return true;
    }
    bool down(int y){
        if(y < ALTURA - 1)
        y = y + 1;
        
        return true;
    }
    bool right(int x){
        if(x < LARGURA - 1)
        x = x + 1;
        
        return true;
    }
    bool left(int x){
        if(x > 0)
        x = x - 1;
        
        return true;
    }
    //IP DO CLIENT 
    char ServerIP[30]={"127.0.0.1"};
    connectToServer(ServerIP);

    while(inicio){
        startTimer();
        while(!al_is_event_queue_empty(eventsQueue)){
            ALLEGRO_EVENT event;
            al_wait_for_event(eventsQueue, &event);
            if(event.type == ALLEGRO_EVENT_KEY_DOWN) inicio = false;
            if(event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) inicio = false;
            al_draw_bitmap(menuImg, 0, 0, 0);
            al_draw_textf(font_1, al_map_rgb(255,0,0), LARGURA/2 - 140, 50, 0, "TARGET");
            al_draw_textf(font_1, al_map_rgb(255,255,255), LARGURA/2 - 335, ALTURA/2 + 40, 0, "PRESS ANY KEY TO BEGIN");
            al_flip_display();
            al_clear_to_color(al_map_rgb(0, 0, 0));
            FPSLimit();
        }
    }
    

    while(menu){
        startTimer();
        while(!al_is_event_queue_empty(eventsQueue)){
            ALLEGRO_EVENT event;
            al_wait_for_event(eventsQueue, &event);
            if(event.type == ALLEGRO_EVENT_KEY_CHAR)
                switch(event.keyboard.keycode){
                    case ALLEGRO_KEY_UP:
                        option--;
                        if(option == 0) option = 4;
                        //al_draw_bitmap(seta, 0, 0, 0);
                        break;
                    case ALLEGRO_KEY_DOWN:
                        option++;
                        if(option == 5) option = 1;

                    case ALLEGRO_KEY_ENTER:
                        // chooseOption();
                        break;

                }
            if(event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) inicio = false;
            al_draw_bitmap(menuImg, 0, 0, 0);
            al_draw_textf(font_1, al_map_rgb(255,255,255), LARGURA/2 - 140, 50, 0, "TARGET");
            al_draw_textf(font_1, al_map_rgb(255,0,0), LARGURA/2 - 50, ALTURA/2 - 100, 0, "START GAME");
            al_draw_textf(font_1, al_map_rgb(255,0,0), LARGURA/2 - 50, ALTURA/2, 0, "HELP");
            al_draw_textf(font_1, al_map_rgb(255,0,0), LARGURA/2 - 50, ALTURA/2 + 100, 0, "CREDITS");
            al_draw_textf(font_1, al_map_rgb(255,0,0), LARGURA/2 - 50, ALTURA/2 + 200, 0, "EXIT GAME");
            switch(option){
                case 1:
                    al_draw_bitmap(seta, LARGURA/2, ALTURA/2 - 100, 0);
                    break;
                case 2:
                    al_draw_bitmap(seta, LARGURA/2, ALTURA/2, 0);
                    break;
                case 3:
                    al_draw_bitmap(seta, LARGURA/2, ALTURA/2 + 100, 0);
                    break;
                case 4:
                    al_draw_bitmap(seta, LARGURA/2, ALTURA/2 + 200, 0);
                    break;
            }
            al_flip_display();
            al_clear_to_color(al_map_rgb(0, 0, 0));
            FPSLimit();
        }
    }
     // while(game){ // AKI A INTERACAO REALEMTE COMECA
     //    startTimer();
     //    while(!al_is_event_queue_empty(eventsQueue)){
     //        ALLEGRO_EVENT event; // CRIA UM EVENTO PRA ARMAZENAR AS ENTRAS RECEBIDAS
     //        al_wait_for_event(eventsQueue, &event); // ESPERA POR UM EVENTO
     //        if(event.type == ALLEGRO_EVENT_KEY_CHAR)
     //        switch(event.keyboard.keycode){
     //            case ALLEGRO_KEY_UP:
     //            if(up(y) == true){
     //                y-=2;
                    
     //            }
     //            break;
                
    //             case ALLEGRO_KEY_DOWN:
    //             if(down(y) == true){
    //                 y+=2;
    //             }
    //             break;
                
    //             case ALLEGRO_KEY_RIGHT:
    //                 if(right(x) == true){
    //                     x+=2;
                        
    //                 }
    //                 break;
                
    //             case ALLEGRO_KEY_LEFT:
    //                 if(left(x) == true){
    //                     x-=2;
    //                 }
    //                 break;
                
    //             case ALLEGRO_KEY_ENTER :
    // 	        	game = false;
    // 	        	break;
    //         }
    //         if(event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) game = false;
        
    //     }
    //     count ++;
    //     al_draw_textf(font_1, al_map_rgb(255,0,255), 10, 10, 0, "Count : %i", count);
    //     al_draw_bitmap(bit3, 96, 96, 0);
    //     al_draw_bitmap_region(tileSet, 64, 64, 32, 32, x, y, 0);
    //     al_draw_filled_circle(x, y, 5, al_map_rgb(255,255,255));
    //     al_flip_display(); // MOSTRA O DISPLAY
    //     al_clear_to_color(al_map_rgb(0, 0, 0));
    //     FPSLimit(); // LAGs
    // }
    return 0;       
}